export const RdirectUrlData ={
  Home:"/",
  LOGIN:"/login",
  SIGNUP:"/signup",
}