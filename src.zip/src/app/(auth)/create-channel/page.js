'use client'

import { useState } from 'react';
import axios from 'axios';
import { useRouter } from 'next/navigation';

export default function CreateChannel() {
  const [channelName, setChannelName] = useState('');
  const [hostName, setHostName] = useState('');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleCreateChannel = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await axios.post('http://localhost:8003/api/create-channel', {
        channelName,
        hostName,
        description,
      });

      const { channelId, token } = response.data;

      // Redirect the host to the live stream page with the generated URL containing the token and channel ID
      router.push(`/live?id=${channelId}&token=${token}&role=host`);
    } catch (error) {
      console.error('Error creating channel', error);
      alert('Error creating channel');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto max-w-md px-4 py-8">
      <h1 className="text-3xl font-bold mb-8 text-center">Create a Live Stream</h1>
      
      <form onSubmit={handleCreateChannel} className="bg-white rounded-lg shadow-md p-6">
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="channelName">
            Channel Name:
          </label>
          <input
            id="channelName"
            type="text"
            value={channelName}
            onChange={(e) => setChannelName(e.target.value)}
            required
            className="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="My Awesome Stream"
          />
        </div>
        
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="hostName">
            Your Name:
          </label>
          <input
            id="hostName"
            type="text"
            value={hostName}
            onChange={(e) => setHostName(e.target.value)}
            required
            className="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="John Doe"
          />
        </div>
        
        <div className="mb-6">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="description">
            Stream Description:
          </label>
          <textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
            className="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500 h-24"
            placeholder="Tell viewers what your stream is about..."
          />
        </div>
        
        <button 
          type="submit" 
          disabled={loading}
          className={`w-full py-3 rounded font-bold text-white ${
            loading ? 'bg-gray-400' : 'bg-blue-500 hover:bg-blue-600'
          }`}
        >
          {loading ? 'Creating Stream...' : 'Go Live Now'}
        </button>
      </form>
      
      <div className="mt-4 text-center">
        <a href="/join" className="text-blue-500 hover:underline">
          Or join an existing stream
        </a>
      </div>
    </div>
  );
}