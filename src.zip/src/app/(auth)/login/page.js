import LoginPage from '@/components/LoginPage'
import React from 'react'

export default function page() {
  return (
    <div>
      <LoginPage/>
    </div>
  )
}
