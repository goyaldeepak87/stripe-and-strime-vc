'use client'

import { useState, useEffect } from 'react';
import axios from 'axios';
import { useRouter } from 'next/navigation';

export default function JoinStream() {
  const [channels, setChannels] = useState([]);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    // Fetch all active channels
    const fetchChannels = async () => {
      try {
        const response = await axios.get('http://localhost:8003/api/active-channels');
        setChannels(response.data);
      } catch (error) {
        console.error('Error fetching channels:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchChannels();
    
    // Set up polling to refresh the list every 30 seconds
    const interval = setInterval(fetchChannels, 30000);
    
    return () => clearInterval(interval);
  }, []);

  const joinChannel = async (channelId) => {
    try {
      // Get viewer token
      const response = await axios.post('http://localhost:8003/api/join-channel', {
        channelId
      });
      
      const { token } = response.data;
      
      // Redirect to the live stream page with token and role=audience
      router.push(`/live?id=${channelId}&token=${token}&role=audience`);
    } catch (error) {
      console.error('Error joining channel:', error);
      alert('Error joining channel');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <p>Loading live channels...</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Join a Live Stream</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {channels.length > 0 ? (
          channels.map((channel) => (
            <div key={channel.channelId} className="border rounded-lg overflow-hidden shadow-md">
              <div className="bg-gray-200 h-48 flex items-center justify-center">
                <span className="text-green-600 flex items-center">
                  <span className="inline-block w-3 h-3 bg-green-500 rounded-full mr-2"></span>
                  LIVE
                </span>
              </div>
              
              <div className="p-4">
                <h2 className="text-xl font-bold">{channel.channelName}</h2>
                <p className="text-gray-600 mb-2">Host: {channel.hostName}</p>
                <p className="text-sm mb-4">{channel.viewers} watching now</p>
                <p className="mb-4">{channel.description}</p>
                
                <button
                  onClick={() => joinChannel(channel.channelId)}
                  className="w-full bg-blue-500 hover:bg-blue-600 text-white py-2 rounded"
                >
                  Join Stream
                </button>
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-full text-center py-12">
            <p className="text-xl text-gray-500">No active streams right now</p>
            <p className="mt-2">
              <a href="/create" className="text-blue-500 hover:underline">Create your own stream</a>
            </p>
          </div>
        )}
      </div>
    </div>
  );
}