import LoginForm from '@/components/LoginPage'
import React from 'react'

export default function page() {
  return (
    <div>
      Payment Cancelled
    </div>
  )
}
