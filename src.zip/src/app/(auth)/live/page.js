'use client'

import { useEffect, useRef, useState } from 'react';
import axios from 'axios';
import { useSearchParams } from 'next/navigation';
import AgoraRTC from 'agora-rtc-sdk-ng';
import { io } from 'socket.io-client'; // Import Socket.io client

export default function LiveStream() {
  const searchParams = useSearchParams();
  const channelId = searchParams.get('id');
  const token = searchParams.get('token');
  const role = searchParams.get('role') || 'audience'; // 'host' or 'audience'

  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [viewers, setViewers] = useState(0);
  const [hostName, setHostName] = useState('');
  const [channelName, setChannelName] = useState('');
  const [isLive, setIsLive] = useState(false);
  
  // Refs for video containers
  const localVideoRef = useRef(null);
  const remoteVideoRef = useRef(null);
  
  // Refs for Agora objects
  const client = useRef(null);
  const localTrack = useRef({
    videoTrack: null,
    audioTrack: null
  });

  useEffect(() => {
    // Fetch channel details
    const fetchChannelDetails = async () => {
      if (!channelId) return;
      
      try {
        const response = await axios.get(`http://localhost:8003/api/channel/${channelId}`);
        setHostName(response.data.hostName);
        setChannelName(response.data.channelName);
      } catch (error) {
        console.error('Error fetching channel details:', error);
      }
    };
    
    fetchChannelDetails();
    
    // Connect to socket for real-time comments
    const socket = io('http://localhost:8003');
    socket.emit('joinChannel', channelId);
    
    socket.on('comment', (comment) => {
      setComments((prev) => [...prev, comment]);
    });
    
    socket.on('viewerCount', (count) => {
      setViewers(count);
    });
    
    return () => {
      socket.disconnect();
    };
  }, [channelId]);

  useEffect(() => {
    if (!channelId || !token) return;
    
    const initAgora = async () => {
      // Create Agora client
      client.current = AgoraRTC.createClient({ mode: 'live', codec: 'vp8' });
      
      try {
        // Set client role based on URL parameter
        client.current.setClientRole(role === 'host' ? 'host' : 'audience');
        
        // Join the channel
        await client.current.join(
          process.env.NEXT_PUBLIC_AGORA_APP_ID, 
          channelId, 
          token, 
          null  // uid will be assigned by Agora automatically
        );
        
        // If user is host, publish tracks
        if (role === 'host') {
          // Create local tracks
          const [audioTrack, videoTrack] = await AgoraRTC.createMicrophoneAndCameraTracks();
          localTrack.current.audioTrack = audioTrack;
          localTrack.current.videoTrack = videoTrack;
          
          // Play local video track
          localTrack.current.videoTrack.play(localVideoRef.current);
          
          // Publish local tracks
          await client.current.publish([audioTrack, videoTrack]);
          setIsLive(true);
        }
        
        // Listen for remote users
        client.current.on('user-published', async (user, mediaType) => {
          // Subscribe to remote user
          await client.current.subscribe(user, mediaType);
          
          // If subscribed to video track
          if (mediaType === 'video') {
            // Play the remote video in remote video container
            user.videoTrack.play(remoteVideoRef.current);
          }
          
          // If subscribed to audio track
          if (mediaType === 'audio') {
            user.audioTrack.play();
          }
        });
        
        // Handle user unpublishing
        client.current.on('user-unpublished', (user, mediaType) => {
          if (mediaType === 'video') {
            if (remoteVideoRef.current) {
              remoteVideoRef.current.innerHTML = '';
            }
          }
          if (mediaType === 'audio') {
            user.audioTrack.stop();
          }
        });
        
      } catch (error) {
        console.error('Error joining Agora channel:', error);
      }
    };
    
    initAgora();
    
    // Cleanup function
    return async () => {
      if (localTrack.current.audioTrack) {
        localTrack.current.audioTrack.close();
      }
      if (localTrack.current.videoTrack) {
        localTrack.current.videoTrack.close();
      }
      await client.current?.leave();
    };
  }, [channelId, token, role]);

  const handleCommentSubmit = async (e) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    
    try {
      // Send comment to the server
      await axios.post('http://localhost:8003/api/comment', {
        channelId,
        comment: newComment,
        userName: 'Anonymous' // You can get this from user authentication
      });
      
      // Clear the input field
      setNewComment('');
    } catch (error) {
      console.error('Error posting comment:', error);
    }
  };

  const endLiveStream = async () => {
    try {
      await axios.post('http://localhost:8003/api/end-stream', { channelId });
      
      // Cleanup local tracks
      if (localTrack.current.audioTrack) {
        localTrack.current.audioTrack.close();
      }
      if (localTrack.current.videoTrack) {
        localTrack.current.videoTrack.close();
      }
      
      // Leave channel
      await client.current?.leave();
      
      // Redirect to home
      window.location.href = '/';
    } catch (error) {
      console.error('Error ending stream:', error);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold">{channelName}</h1>
          <p className="text-gray-600">Hosted by: {hostName}</p>
          <p className="text-sm">{viewers} viewers</p>
        </div>
        {role === 'host' && (
          <button 
            onClick={endLiveStream}
            className="bg-red-500 text-white px-4 py-2 rounded"
          >
            End Stream
          </button>
        )}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          {/* Video container */}
          <div className="bg-black rounded-lg overflow-hidden" style={{ height: '480px' }}>
            {role === 'host' ? (
              <div ref={localVideoRef} className="w-full h-full"></div>
            ) : (
              <div ref={remoteVideoRef} className="w-full h-full"></div>
            )}
            
            {/* Show loading state when stream is not ready */}
            {(role === 'audience' && remoteVideoRef.current?.childElementCount === 0) && (
              <div className="flex items-center justify-center h-full">
                <p className="text-white">Waiting for host to go live...</p>
              </div>
            )}
          </div>
          
          {/* Stream status indicator */}
          {role === 'host' && (
            <div className="mt-4 p-3 bg-gray-100 rounded">
              <p>
                {isLive ? (
                  <span className="text-green-500 font-bold flex items-center">
                    <span className="inline-block w-3 h-3 bg-green-500 rounded-full mr-2"></span>
                    Live Now
                  </span>
                ) : (
                  <span className="text-gray-500">Setting up stream...</span>
                )}
              </p>
              {isLive && (
                <p className="text-sm mt-2">
                  Share this link to invite viewers: 
                  <code className="bg-gray-200 px-2 py-1 ml-2 rounded">
                    {`${window.location.origin}/join?id=${channelId}`}
                  </code>
                </p>
              )}
            </div>
          )}
        </div>
        
        {/* Comments section */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <h2 className="text-xl font-bold mb-4">Comments</h2>
          <div className="h-96 overflow-y-auto mb-4">
            {comments.length > 0 ? (
              comments.map((comment, index) => (
                <div key={index} className="mb-3 p-3 bg-white rounded shadow-sm">
                  <p className="font-semibold text-sm">{comment.userName || 'Anonymous'}</p>
                  <p>{comment.text}</p>
                </div>
              ))
            ) : (
              <p className="text-gray-500 text-center">No comments yet</p>
            )}
          </div>
          
          <form onSubmit={handleCommentSubmit} className="mt-auto">
            <div className="flex">
              <input
                type="text"
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Add a comment..."
                className="flex-grow p-2 border rounded-l"
              />
              <button 
                type="submit"
                className="bg-blue-500 text-white px-4 py-2 rounded-r"
              >
                Send
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}