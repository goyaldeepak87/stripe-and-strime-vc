module.exports = {

"[project]/src/lang/index.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "LoaderData": (()=>LoaderData),
    "LoginData": (()=>LoginData),
    "SignupData": (()=>SignupData),
    "VideocallData": (()=>VideocallData),
    "animations": (()=>animations),
    "successPayment": (()=>successPayment)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/Animation.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation2$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/Animation2.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation3$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/Animation3.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation4$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/Animation4.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Loader$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/Loader.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$success$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/success.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$videocall$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/videocall.json (json)");
;
;
;
;
;
;
;
const animations = [
    {
        id: 1,
        active: true,
        prodectId: "ReTiChat11",
        title: "Real - Time Stream Chat",
        label: "Live Chat Feature",
        text: "Engage with your audience instantly using our live stream chat feature. Perfect for creators, teachers, or hosts who want real-time interaction during any broadcast or live session.",
        price: 5,
        leftShift: "1/2",
        topShift: "15",
        lftShiftIline: "125",
        topShiftIline: "60",
        animation: {
            img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation$2e$json__$28$json$29$__["default"],
            width: 120,
            height: 120
        }
    },
    {
        id: 2,
        active: false,
        prodectId: "ViCaLiComments12",
        title: "Video Call & Live Comments",
        label: "Interactive Video Call",
        text: " seamless video calls with the added power of live commenting. Collaborate, teach, or connect with multiple users while engaging them through real-time feedback and chat interactions.",
        price: 12,
        leftShift: "25",
        topShift: "15",
        topShiftIline: "61",
        lftShiftIline: "110",
        animation: {
            img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation2$2e$json__$28$json$29$__["default"],
            width: 190,
            height: 140
        }
    },
    {
        id: 3,
        active: true,
        prodectId: "ScSharCalls13",
        title: "Screen Sharing in Calls",
        label: "Screen Share Tool",
        text: "Share your screen effortlessly during video calls. Ideal for presentations, demos, remote support, or online teaching — make your sessions more interactive and visually rich.",
        price: 18,
        leftShift: "20",
        lftShiftIline: "75",
        topShiftIline: "75",
        animation: {
            img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation3$2e$json__$28$json$29$__["default"],
            width: 226,
            height: 134
        }
    }
];
const LoginData = {
    animation: {
        img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation4$2e$json__$28$json$29$__["default"],
        width: 330,
        height: 330
    }
};
const successPayment = {
    animation: {
        img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$success$2e$json__$28$json$29$__["default"],
        width: 330,
        height: 330
    }
};
const LoaderData = {
    animation: {
        img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Loader$2e$json__$28$json$29$__["default"],
        width: 110,
        height: 24
    }
};
const VideocallData = {
    animation: {
        img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$videocall$2e$json__$28$json$29$__["default"],
        width: 150,
        height: 130
    }
};
const SignupData = [
    {
        id: 1,
        icon: "https://www.svgrepo.com/show/355037/google.svg",
        label: "Google"
    },
    {
        id: 2,
        icon: "https://www.svgrepo.com/show/157818/facebook.svg",
        label: "Facebook"
    }
];
}}),
"[project]/src/lang/RdirectUrl.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "RdirectUrlData": (()=>RdirectUrlData)
});
const RdirectUrlData = {
    Home: "/",
    LOGIN: "/login",
    SIGNUP: "/signup"
};
}}),
"[project]/src/utils/validationSchema.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "validateLoginForm": (()=>validateLoginForm)
});
const validateLoginForm = (values)=>{
    const errors = {};
    // Email Validation
    if (!values.email) {
        errors.email = 'Email is required';
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email)) {
        errors.email = 'Invalid email address';
    }
    // Password Validation
    if (!values.password) {
        errors.password = 'Password is required';
    } else if (values.password.length < 6) {
        errors.password = 'Password must be at least 6 characters';
    }
    return errors;
};
}}),

};

//# sourceMappingURL=src_8ff42ddd._.js.map