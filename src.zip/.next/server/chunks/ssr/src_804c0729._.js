module.exports = {

"[project]/src/lang/index.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "LoginData": (()=>LoginData),
    "SignupData": (()=>SignupData),
    "animations": (()=>animations)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/Animation.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation2$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/Animation2.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation3$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/Animation3.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation4$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/Animation4.json (json)");
;
;
;
;
const animations = [
    {
        id: 1,
        label: "Card1",
        leftShift: "1/2",
        topShift: "15",
        lftShiftIline: "125",
        topShiftIline: "60",
        animation: {
            img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation$2e$json__$28$json$29$__["default"],
            width: 120,
            height: 120
        }
    },
    {
        id: 2,
        label: "Card2",
        leftShift: "25",
        topShift: "15",
        topShiftIline: "61",
        lftShiftIline: "110",
        animation: {
            img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation2$2e$json__$28$json$29$__["default"],
            width: 190,
            height: 140
        }
    },
    {
        id: 3,
        label: "Card3",
        leftShift: "20",
        lftShiftIline: "75",
        topShiftIline: "75",
        animation: {
            img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation3$2e$json__$28$json$29$__["default"],
            width: 226,
            height: 134
        }
    }
];
const LoginData = {
    animation: {
        img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation4$2e$json__$28$json$29$__["default"],
        width: 330,
        height: 330
    }
};
const SignupData = [
    {
        id: 1,
        icon: "https://www.svgrepo.com/show/355037/google.svg",
        label: "Google"
    },
    {
        id: 2,
        icon: "https://www.svgrepo.com/show/157818/facebook.svg",
        label: "Facebook"
    }
];
}}),
"[project]/src/lang/RdirectUrl.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "RdirectUrlData": (()=>RdirectUrlData)
});
const RdirectUrlData = {
    Home: "/",
    LOGIN: "/login",
    SIGNUP: "/signup"
};
}}),
"[project]/src/utils/validationSchema.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "validateLoginForm": (()=>validateLoginForm)
});
const validateLoginForm = (values)=>{
    const errors = {};
    // Email Validation
    if (!values.email) {
        errors.email = 'Email is required';
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email)) {
        errors.email = 'Invalid email address';
    }
    // Password Validation
    if (!values.password) {
        errors.password = 'Password is required';
    } else if (values.password.length < 6) {
        errors.password = 'Password must be at least 6 characters';
    }
    return errors;
};
}}),
"[project]/src/reudux/slice/authSlice.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// src/redux/slice/authSlice.js
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__),
    "loginFailure": (()=>loginFailure),
    "loginRequest": (()=>loginRequest),
    "loginSuccess": (()=>loginSuccess),
    "logout": (()=>logout)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
;
const authSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: 'auth',
    initialState: {
        user: null,
        isAuthenticated: false,
        loading: false,
        error: null
    },
    reducers: {
        loginRequest (state) {
            state.loading = true;
            state.error = null; // Reset error on new login attempt
        },
        loginSuccess (state, action) {
            state.loading = false;
            state.isAuthenticated = true;
            state.user = action.payload; // Set user data upon successful login
        },
        loginFailure (state, action) {
            state.loading = false;
            state.error = action.payload; // Set error message
        },
        logout (state) {
            state.isAuthenticated = false;
            state.user = null; // Clear user data upon logout
        }
    }
});
const { loginRequest, loginSuccess, loginFailure, logout } = authSlice.actions;
const __TURBOPACK__default__export__ = authSlice.reducer;
}}),

};

//# sourceMappingURL=src_804c0729._.js.map