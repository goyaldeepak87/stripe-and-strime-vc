(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(auth)_create-channel_page_948e2e4a.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(auth)_create-channel_page_948e2e4a.js",
  "chunks": [
    "static/chunks/_e26dcd50._.js"
  ],
  "source": "dynamic"
});
