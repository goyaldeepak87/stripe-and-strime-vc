(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_f0e4c1a2.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_f0e4c1a2.js",
  "chunks": [
    "static/chunks/[root of the server]__1b2dcb78._.css",
    "static/chunks/node_modules_8a70c09e._.js",
    "static/chunks/src_reudux_1212298e._.js"
  ],
  "source": "dynamic"
});
