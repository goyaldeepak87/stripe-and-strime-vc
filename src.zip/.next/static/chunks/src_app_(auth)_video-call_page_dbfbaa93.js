(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(auth)_video-call_page_dbfbaa93.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(auth)_video-call_page_dbfbaa93.js",
  "chunks": [
    "static/chunks/node_modules_agora-rtc-sdk-ng_AgoraRTC_N-production_ad4ad12c.js",
    "static/chunks/node_modules_2e331219._.js",
    "static/chunks/src_components_LiveStream_7c9b45c2.js"
  ],
  "source": "dynamic"
});
