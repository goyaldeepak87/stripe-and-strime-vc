(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(auth)_live_page_948e2e4a.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(auth)_live_page_948e2e4a.js",
  "chunks": [
    "static/chunks/node_modules_agora-rtc-sdk-ng_AgoraRTC_N-production_ad4ad12c.js",
    "static/chunks/node_modules_b791d6d0._.js",
    "static/chunks/src_app_(auth)_live_page_f0e9062a.js"
  ],
  "source": "dynamic"
});
