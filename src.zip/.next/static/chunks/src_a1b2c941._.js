(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_a1b2c941._.js", {

"[project]/src/lang/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "LoaderData": (()=>LoaderData),
    "LoginData": (()=>LoginData),
    "SignupData": (()=>SignupData),
    "VideocallData": (()=>VideocallData),
    "animations": (()=>animations),
    "successPayment": (()=>successPayment)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/Animation.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation2$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/Animation2.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation3$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/Animation3.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation4$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/Animation4.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Loader$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/Loader.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$success$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/success.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$videocall$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/videocall.json (json)");
;
;
;
;
;
;
;
const animations = [
    {
        id: 1,
        active: true,
        prodectId: "ReTiChat11",
        title: "Real - Time Stream Chat",
        label: "Live Chat Feature",
        text: "Engage with your audience instantly using our live stream chat feature. Perfect for creators, teachers, or hosts who want real-time interaction during any broadcast or live session.",
        price: "$5",
        leftShift: "1/2",
        topShift: "15",
        lftShiftIline: "125",
        topShiftIline: "60",
        animation: {
            img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation$2e$json__$28$json$29$__["default"],
            width: 120,
            height: 120
        }
    },
    {
        id: 2,
        active: false,
        prodectId: "ViCaLiComments12",
        title: "Video Call & Live Comments",
        label: "Interactive Video Call",
        text: " seamless video calls with the added power of live commenting. Collaborate, teach, or connect with multiple users while engaging them through real-time feedback and chat interactions.",
        price: "$12",
        leftShift: "25",
        topShift: "15",
        topShiftIline: "61",
        lftShiftIline: "110",
        animation: {
            img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation2$2e$json__$28$json$29$__["default"],
            width: 190,
            height: 140
        }
    },
    {
        id: 3,
        active: true,
        prodectId: "ScSharCalls13",
        title: "Screen Sharing in Calls",
        label: "Screen Share Tool",
        text: "Share your screen effortlessly during video calls. Ideal for presentations, demos, remote support, or online teaching — make your sessions more interactive and visually rich.",
        price: "$18",
        leftShift: "20",
        lftShiftIline: "75",
        topShiftIline: "75",
        animation: {
            img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation3$2e$json__$28$json$29$__["default"],
            width: 226,
            height: 134
        }
    }
];
const LoginData = {
    animation: {
        img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation4$2e$json__$28$json$29$__["default"],
        width: 330,
        height: 330
    }
};
const successPayment = {
    animation: {
        img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$success$2e$json__$28$json$29$__["default"],
        width: 330,
        height: 330
    }
};
const LoaderData = {
    animation: {
        img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Loader$2e$json__$28$json$29$__["default"],
        width: 110,
        height: 24
    }
};
const VideocallData = {
    animation: {
        img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$videocall$2e$json__$28$json$29$__["default"],
        width: 150,
        height: 130
    }
};
const SignupData = [
    {
        id: 1,
        icon: "https://www.svgrepo.com/show/355037/google.svg",
        label: "Google"
    },
    {
        id: 2,
        icon: "https://www.svgrepo.com/show/157818/facebook.svg",
        label: "Facebook"
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/lang/RdirectUrl.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "RdirectUrlData": (()=>RdirectUrlData)
});
const RdirectUrlData = {
    Home: "/",
    LOGIN: "/login",
    SIGNUP: "/signup"
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/(auth)/live-calls/page.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// NEXT_PUBLIC_BASE_URL = http://localhost:8003/v1
// NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY = pk_test_51R9ONz2aFywf1JUEg7uaP6ouz6TvPP3ZU2JLeXkOX1TFTIipoHku1G0wbaUZFRJW3qGLqRkAkgVuABSt06tarc4J00ndfTXt4C
// NEXT_PUBLIC_STRIPE_SECRET_KEY = sk_test_51R9ONz2aFywf1JUEgc6yDNswm4pzy2rROt0H55lqmoWMmjpYynAhFOi4fUemOKOYo7KG5TukTXucsPuRFFUDg9au0033Vbf48w
__turbopack_context__.s({
    "default": (()=>page)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$commanComp$2f$UserList$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/commanComp/UserList.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$commanComp$2f$UserProfileModel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/commanComp/UserProfileModel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$NaveBar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/NaveBar.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function page() {
    _s();
    const fetchUserProfile = async ()=>{
        try {
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get('http://localhost:8003/v1/user/api/profile', {
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            console.log("Response", response.data); // Log the response data
            return response.data; // Return the data for further use
        } catch (error) {
            console.error("Error fetching user profile:", error.message);
        // Handle the error appropriately (e.g., show a toast notification or set an error state)
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "page.useEffect": ()=>{
            const fetchData = {
                "page.useEffect.fetchData": async ()=>{
                    const userProfile = await fetchUserProfile();
                    console.log("User Profile", userProfile); // Log the fetched user profile
                }
            }["page.useEffect.fetchData"];
            fetchData();
        }
    }["page.useEffect"], []); // Empty dependency array to run once on component mount
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$NaveBar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/app/(auth)/live-calls/page.js",
                lineNumber: 40,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mx-auto max-w-7xl px-2 sm:px-6 lg:px-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-2xl font-bold mt-10",
                        children: "Pocket Live Calls User"
                    }, void 0, false, {
                        fileName: "[project]/src/app/(auth)/live-calls/page.js",
                        lineNumber: 42,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-10",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex h-[calc(100vh-176px)]",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-1/3 h-full overflow-y-auto pb-6 pl-6 border border-gray-500",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$commanComp$2f$UserList$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                            fileName: "[project]/src/app/(auth)/live-calls/page.js",
                                            lineNumber: 48,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$commanComp$2f$UserList$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                            fileName: "[project]/src/app/(auth)/live-calls/page.js",
                                            lineNumber: 49,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$commanComp$2f$UserList$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                            fileName: "[project]/src/app/(auth)/live-calls/page.js",
                                            lineNumber: 50,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$commanComp$2f$UserList$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                            fileName: "[project]/src/app/(auth)/live-calls/page.js",
                                            lineNumber: 51,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$commanComp$2f$UserList$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                            fileName: "[project]/src/app/(auth)/live-calls/page.js",
                                            lineNumber: 52,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$commanComp$2f$UserList$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                            fileName: "[project]/src/app/(auth)/live-calls/page.js",
                                            lineNumber: 53,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$commanComp$2f$UserList$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                            fileName: "[project]/src/app/(auth)/live-calls/page.js",
                                            lineNumber: 54,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/(auth)/live-calls/page.js",
                                    lineNumber: 47,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-1/2 ml-10",
                                    style: {
                                        width: "63.5%"
                                    },
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$commanComp$2f$UserProfileModel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                        fileName: "[project]/src/app/(auth)/live-calls/page.js",
                                        lineNumber: 57,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/(auth)/live-calls/page.js",
                                    lineNumber: 56,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/(auth)/live-calls/page.js",
                            lineNumber: 46,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/(auth)/live-calls/page.js",
                        lineNumber: 45,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/(auth)/live-calls/page.js",
                lineNumber: 41,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/(auth)/live-calls/page.js",
        lineNumber: 39,
        columnNumber: 5
    }, this);
}
_s(page, "OD7bBpZva5O2jO+Puf00hKivP7c=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_a1b2c941._.js.map