(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(auth)_create-channel_page_dbfbaa93.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(auth)_create-channel_page_dbfbaa93.js",
  "chunks": [
    "static/chunks/node_modules_next_f9167031._.js",
    "static/chunks/src_app_(auth)_create-channel_page_9fb571bb.js"
  ],
  "source": "dynamic"
});
