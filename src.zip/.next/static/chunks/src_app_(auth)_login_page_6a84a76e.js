(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(auth)_login_page_6a84a76e.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(auth)_login_page_6a84a76e.js",
  "chunks": [
    "static/chunks/src_components_images_Animation_json_f01bea38._.js",
    "static/chunks/src_components_images_Animation2_json_a0c9045f._.js",
    "static/chunks/src_components_images_Animation3_json_7339c93d._.js",
    "static/chunks/src_components_images_Animation4_json_72f805a3._.js",
    "static/chunks/src_components_e200d661._.js",
    "static/chunks/src_c62436d2._.js",
    "static/chunks/node_modules_b7fb244f._.js"
  ],
  "source": "dynamic"
});
