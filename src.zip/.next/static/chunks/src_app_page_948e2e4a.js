(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_948e2e4a.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_948e2e4a.js",
  "chunks": [
    "static/chunks/src_components_images_Animation_json_f01bea38._.js",
    "static/chunks/src_components_images_Animation2_json_a0c9045f._.js",
    "static/chunks/src_components_images_Animation3_json_7339c93d._.js",
    "static/chunks/src_components_images_Animation4_json_72f805a3._.js",
    "static/chunks/src_components_images_619f4e6b._.js",
    "static/chunks/src_components_a8466cd4._.js",
    "static/chunks/src_36318dbd._.js",
    "static/chunks/node_modules_17546369._.js"
  ],
  "source": "dynamic"
});
