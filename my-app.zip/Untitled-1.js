/*At method 
at method is used in array of index find through find the value
*/

// const arr1 = [10, 20, 30, 40, 50]
// console.log(arr1.at(1))


/*Concat 
Concat method is used in merrage in two array and convert in singal array and return the new array
*/
// const arr2 = [10, 20, 30]
// const arr3 = [40, 50, 60, 70]

// console.log(arr2.concat(arr3))
// console.log(arr2, arr3)


/*Enteries Method
Entery method give the array of indexing key value pair give
*/
// const arr4 = [10, 20, 30, 40]
// // const KeyValue = arr4.entries
// const data = arr4.entries()
// let obj = {}
// for (let i = 0; i < arr4.length; i++) {
//     const keyvalue = data.next().value
//     obj[keyvalue[0]] = keyvalue[1]
// }
// console.log(obj)

/*Every method
Every method is used check the each element of the array in provided function and this function either return true and false for each iteam. 
*/

// const arr5 = [10, 20, 30, 55, 88]

// const NewCheckValue = arr5.every((item) => item < 90)

// console.log("NewCheckValue", NewCheckValue)

/* Fill method
fill method is change all element with in the range inside the array  and modifining the array existing
*/
// const arr6 = [10, 20, 30, 55, 88]

// console.log(arr6.fill(0, 2,6))
// console.log(arr6)

/*Filter Method
filter method is used shollow copy of a portion in a given array and filter out of eachelement of given array 
*/

const arr7 = [10, 20, 30, 55, 88]
const newarr = arr7.filter((e) => e)
console.log("newarr==>", newarr)