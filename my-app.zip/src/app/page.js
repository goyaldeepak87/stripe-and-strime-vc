import CardCompUI from "@/components/CardCompUI";
import NaveBar from "@/components/NaveBar";
import Image from "next/image";

export default function Home() {
  return (
    <>
    <NaveBar />
    <CardCompUI />
    </>
  );
}
