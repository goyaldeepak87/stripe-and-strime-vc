(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_f0e4c1a2.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_f0e4c1a2.js",
  "chunks": [
    "static/chunks/[root of the server]__860c0698._.css"
  ],
  "source": "dynamic"
});
