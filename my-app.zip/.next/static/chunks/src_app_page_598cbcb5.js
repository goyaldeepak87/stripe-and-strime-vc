(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_598cbcb5.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_598cbcb5.js",
  "chunks": [
    "static/chunks/node_modules_next_0766a282._.js",
    "static/chunks/src_components_CardCompUI_2fe22fbd.js"
  ],
  "source": "dynamic"
});
