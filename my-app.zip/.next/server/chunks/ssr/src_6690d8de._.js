module.exports = {

"[project]/src/lang/index.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "LoaderData": (()=>LoaderData),
    "LoginData": (()=>LoginData),
    "SignupData": (()=>SignupData),
    "VideocallData": (()=>VideocallData),
    "animations": (()=>animations),
    "successPayment": (()=>successPayment)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/Animation.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation2$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/Animation2.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation3$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/Animation3.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation4$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/Animation4.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Loader$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/Loader.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$success$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/success.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$videocall$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/src/components/images/videocall.json (json)");
;
;
;
;
;
;
;
const animations = [
    {
        id: 1,
        active: true,
        prodectId: "ReTiChat11",
        title: "Real - Time Stream Chat",
        label: "Live Chat Feature",
        text: "Engage with your audience instantly using our live stream chat feature. Perfect for creators, teachers, or hosts who want real-time interaction during any broadcast or live session.",
        price: 5,
        leftShift: "1/2",
        topShift: "15",
        lftShiftIline: "125",
        topShiftIline: "60",
        animation: {
            img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation$2e$json__$28$json$29$__["default"],
            width: 120,
            height: 120
        }
    },
    {
        id: 2,
        active: false,
        prodectId: "ViCaLiComments12",
        title: "Video Call & Live Comments",
        label: "Interactive Video Call",
        text: " seamless video calls with the added power of live commenting. Collaborate, teach, or connect with multiple users while engaging them through real-time feedback and chat interactions.",
        price: 12,
        leftShift: "25",
        topShift: "15",
        topShiftIline: "61",
        lftShiftIline: "110",
        animation: {
            img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation2$2e$json__$28$json$29$__["default"],
            width: 190,
            height: 140
        }
    },
    {
        id: 3,
        active: true,
        prodectId: "ScSharCalls13",
        title: "Screen Sharing in Calls",
        label: "Screen Share Tool",
        text: "Share your screen effortlessly during video calls. Ideal for presentations, demos, remote support, or online teaching — make your sessions more interactive and visually rich.",
        price: 18,
        leftShift: "20",
        lftShiftIline: "75",
        topShiftIline: "75",
        animation: {
            img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation3$2e$json__$28$json$29$__["default"],
            width: 226,
            height: 134
        }
    }
];
const LoginData = {
    animation: {
        img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Animation4$2e$json__$28$json$29$__["default"],
        width: 330,
        height: 330
    }
};
const successPayment = {
    animation: {
        img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$success$2e$json__$28$json$29$__["default"],
        width: 330,
        height: 330
    }
};
const LoaderData = {
    animation: {
        img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$Loader$2e$json__$28$json$29$__["default"],
        width: 110,
        height: 24
    }
};
const VideocallData = {
    animation: {
        img: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$images$2f$videocall$2e$json__$28$json$29$__["default"],
        width: 150,
        height: 130
    }
};
const SignupData = [
    {
        id: 1,
        icon: "https://www.svgrepo.com/show/355037/google.svg",
        label: "Google"
    },
    {
        id: 2,
        icon: "https://www.svgrepo.com/show/157818/facebook.svg",
        label: "Facebook"
    }
];
}}),
"[project]/src/lang/RdirectUrl.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "RdirectUrlData": (()=>RdirectUrlData)
});
const RdirectUrlData = {
    Home: "/",
    LOGIN: "/login",
    SIGNUP: "/signup",
    CREATECHANNEL: "/create-channel",
    ROME: "/room"
};
}}),
"[project]/src/utils/validationSchema.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "validateLoginForm": (()=>validateLoginForm)
});
const validateLoginForm = (values)=>{
    const errors = {};
    // Email Validation
    if (!values.email) {
        errors.email = 'Email is required';
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email)) {
        errors.email = 'Invalid email address';
    }
    // Password Validation
    if (!values.password) {
        errors.password = 'Password is required';
    } else if (values.password.length < 6) {
        errors.password = 'Password must be at least 6 characters';
    }
    return errors;
};
}}),
"[project]/src/utils/DefaultHeader.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "DefaultHeader": (()=>DefaultHeader)
});
const DefaultHeader = async ()=>{
    const headers = {
        "Content-Type": "application/json",
        "app-environment": "development",
        "device-name": "web_device",
        "device-id": "deviceId",
        "device-type": "web",
        "ip-address": "IPAddress",
        "os-version": "os"
    };
    return headers;
};
}}),
"[project]/src/utils/APIs.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "connectSocket": (()=>connectSocket),
    "createRoom": (()=>createRoom),
    "disconnectSocket": (()=>disconnectSocket),
    "getAgoraToken": (()=>getAgoraToken),
    "getAllRooms": (()=>getAllRooms),
    "getRoomInfo": (()=>getRoomInfo),
    "getUserProfile": (()=>getUserProfile),
    "getpaymentSuccess": (()=>getpaymentSuccess),
    "joinRoom": (()=>joinRoom),
    "leaveRoom": (()=>leaveRoom),
    "productPayment": (()=>productPayment),
    "socket": (()=>socket)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$socket$2e$io$2d$client$2f$build$2f$esm$2d$debug$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/socket.io-client/build/esm-debug/index.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$socket$2e$io$2d$client$2f$build$2f$esm$2d$debug$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/socket.io-client/build/esm-debug/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$DefaultHeader$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/DefaultHeader.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$appBaseUrl$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/appBaseUrl.js [app-ssr] (ecmascript)");
;
;
;
;
const API_URL = ("TURBOPACK compile-time value", "http://localhost:4000") || "http://localhost:4000/api";
const SERVER_URL = ("TURBOPACK compile-time value", "http://localhost:4000") || "http://localhost:4000";
const getUserProfile = async ()=>{
    try {
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$appBaseUrl$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["API_BASE_URL"]}/user/api/user_list`, {
            headers: {
                ...await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$DefaultHeader$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DefaultHeader"])(),
                Authorization: `Bearer ${localStorage.getItem("token")}`
            }
        });
        return res.data;
    } catch (error) {
        // console.error("Error fetching user profile:", error.message);
        throw error; // Rethrow the error for further handling if needed
    }
};
const getpaymentSuccess = async ({ sessionId })=>{
    try {
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$appBaseUrl$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["API_BASE_URL"]}/user/api/payment_success?session_id=${sessionId}`, {
            headers: {
                ...await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$DefaultHeader$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DefaultHeader"])(),
                Authorization: `Bearer ${localStorage.getItem("token")}`
            }
        });
        return res.data;
    } catch (error) {
        // console.error("Error fetching payment success:", error.message);
        throw error; // Rethrow the error for further handling if needed
    }
};
const productPayment = async (cardData)=>{
    try {
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$appBaseUrl$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["API_BASE_URL"]}/user/api/checkout_sessions`, cardData, {
            headers: {
                ...await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$DefaultHeader$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DefaultHeader"])(),
                Authorization: `Bearer ${localStorage.getItem("token")}`
            }
        });
        return res.data;
    } catch (error) {
        // console.error("Error fetching payment:", error.message);
        throw error; // Rethrow the error for further handling if needed
    }
};
// Get Agora token from our backend
// export const getAgoraToken = async ({ channelName, uid, role }) => {
//     try {
//       const response = await axios.post(`${API_URL}/token`, {
//         channelName,
//         uid,
//         role
//       });
//       return response.data;
//     } catch (error) {
//       console.error("Error getting Agora token:", error);
//       throw error;
//     }
//   };
//   // Join a room
//   export const joinRoom = async ({ roomId, username, role }) => {
//     try {
//       const response = await axios.post(`${API_URL}/rooms/join`, {
//         roomId,
//         username,
//         role
//       });
//       return response.data;
//     } catch (error) {
//       console.error("Error joining room:", error);
//       throw error;
//     }
//   };
//   // Leave a room
//   export const leaveRoom = async ({ roomId, username }) => {
//     try {
//       const response = await axios.post(`${API_URL}/rooms/leave`, {
//         roomId,
//         username
//       });
//       return response.data;
//     } catch (error) {
//       console.error("Error leaving room:", error);
//       throw error;
//     }
//   };
//   // Get room info
//   export const getRoomInfo = async (roomId) => {
//     try {
//       const response = await axios.get(`${API_URL}/rooms/${roomId}`);
//       return response.data;
//     } catch (error) {
//       console.error("Error getting room info:", error);
//       throw error;
//     }
//   };
// Configure axios with defaults
const api = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: API_URL,
    timeout: 10000,
    headers: {
        'Content-Type': 'application/json'
    }
});
// Add response interceptor for better error handling
api.interceptors.response.use((response)=>response, (error)=>{
    console.log("API Error:", error);
    // Check if we have a response in the error
    if (error.response) {
        // Server responded with a status code outside of 2xx
        console.log("Error response data:", error.response.data);
        console.log("Error response status:", error.response.status);
        // Customize error message based on status
        if (error.response.status === 404) {
            error.customMessage = "Resource not found. Please check if the URL is correct.";
        } else if (error.response.status === 500) {
            error.customMessage = "Server error. Please try again later.";
        }
    } else if (error.request) {
        // Request was made but no response received
        console.log("Error request:", error.request);
        error.customMessage = "No response from server. Please check your connection.";
    } else {
        // Something happened in setting up the request
        console.log("Error message:", error.message);
        error.customMessage = "Request failed. Please try again.";
    }
    return Promise.reject(error);
});
const socket = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$socket$2e$io$2d$client$2f$build$2f$esm$2d$debug$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["io"])(SERVER_URL, {
    autoConnect: false,
    reconnection: true,
    reconnectionAttempts: 5,
    reconnectionDelay: 1000,
    transports: [
        'websocket',
        'polling'
    ]
});
const connectSocket = ()=>{
    if (!socket.connected) {
        console.log("Connecting to socket server...");
        socket.connect();
    }
};
const disconnectSocket = ()=>{
    if (socket.connected) {
        console.log("Disconnecting from socket server...");
        socket.disconnect();
    }
};
// Log socket connection events
socket.on('connect', ()=>{
    console.log('Socket connected successfully');
});
socket.on('connect_error', (error)=>{
    console.error('Socket connection error:', error.message);
});
const getAgoraToken = async ({ channelName, uid, role })=>{
    try {
        console.log(`Getting token for channel: ${channelName}, uid: ${uid}, role: ${role}`);
        const response = await api.post(`/token`, {
            channelName,
            uid,
            role
        });
        console.log("Token received:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error getting Agora token:", error);
        throw error;
    }
};
const createRoom = async ({ roomId, username, role })=>{
    try {
        const response = await api.post(`/rooms/create`, {
            roomId,
            username,
            role
        });
        return response.data;
    } catch (error) {
        console.error("Error creating room:", error);
        throw error;
    }
};
const joinRoom = async ({ roomId, username, role })=>{
    try {
        const response = await api.post(`/rooms/join`, {
            roomId,
            username,
            role
        });
        return response.data;
    } catch (error) {
        console.error("Error joining room:", error);
        throw error;
    }
};
const leaveRoom = async ({ roomId, userId })=>{
    try {
        const response = await api.post(`/rooms/leave`, {
            roomId,
            userId
        });
        return response.data;
    } catch (error) {
        console.error("Error leaving room:", error);
        throw error;
    }
};
const getRoomInfo = async (roomId)=>{
    try {
        if (!roomId) {
            throw new Error("Room ID is required");
        }
        const response = await api.get(`/rooms/${roomId}`);
        return response.data;
    } catch (error) {
        console.error("Error getting room info:", error);
        // Return a default response for 404 errors
        if (error.response && error.response.status === 404) {
            return {
                roomId,
                usersCount: 0,
                hostCount: 0,
                isActive: false,
                exists: false,
                success: false,
                error: "Room not found"
            };
        }
        throw error;
    }
};
const getAllRooms = async ()=>{
    try {
        const response = await api.get(`/rooms`);
        return response.data;
    } catch (error) {
        console.error("Error getting rooms list:", error);
        throw error;
    }
};
}}),
"[project]/src/config/appBaseUrl.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "API_BASE_URL": (()=>API_BASE_URL)
});
const API_BASE_URL = ("TURBOPACK compile-time value", "http://localhost:4000/v1") || "http://localhost:4000/v1";
}}),
"[project]/src/app/(auth)/success/page.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>page)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$GifComp$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/GifComp.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LoginPage$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/LoginPage.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lang$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lang/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$reudux$2f$slice$2f$authSlice$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/reudux/slice/authSlice.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$APIs$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/APIs.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
function page() {
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const sessionId = searchParams.get('session_id');
    const dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useDispatch"])();
    const paymentStatus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSelector"])((state)=>state.auth.paymentStatus);
    (function() {
        setTimeout(()=>{
            window.location.href = "/create-channel";
        }, 2000);
    })();
    const checkPaymentSuccess = async ()=>{
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$APIs$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getpaymentSuccess"])({
            sessionId
        }).then((result)=>{
            if (result?.statusCode === 200) {
                if (result?.data?.result?.payment_status === "completed") {
                    dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$reudux$2f$slice$2f$authSlice$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["updatePaymentStatus"])("paid"));
                }
            }
        // console.log("dtaa==>", result)
        // console.log("User Profile:", response.data.result);
        }).catch((error)=>{
        // console.error("Error fetching user profile:", error);
        });
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        checkPaymentSuccess();
    }, [
        sessionId
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex min-h-screen items-center justify-center",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$GifComp$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
            ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lang$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["successPayment"]
        }, void 0, false, {
            fileName: "[project]/src/app/(auth)/success/page.js",
            lineNumber: 45,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/(auth)/success/page.js",
        lineNumber: 44,
        columnNumber: 5
    }, this);
}
}}),

};

//# sourceMappingURL=src_6690d8de._.js.map